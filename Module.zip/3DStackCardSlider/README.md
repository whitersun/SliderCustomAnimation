SliderCard

1. Add slider
    File js/info.js
2. ....